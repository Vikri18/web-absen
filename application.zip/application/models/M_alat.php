<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_alat extends CI_Model
{

    public function getUserid($rfid)
    {
        $this->db->select('id');
        $this->db->where('rfid', $rfid);
        return $this->db->get('users');
    }

    public function submitAbsen_api($data)
    {
        if ($this->db->insert('absen', $data)) {
            return true;
        }
    }
}
