<?php
defined('BASEPATH') or exit('No direct script access allowed');

use chriskacerguis\RestServer\RestController;

class Alat extends RestController
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('m_alat');
        date_default_timezone_set('Asia/Jakarta');
    }


    public function daftarUser_post()
    {
        $rfid = $this->post('rfid');
        $idAlat = $this->post('idAlat');

        
    }

    public function inputAbsen_post()
    {
        $rfid = $this->post('rfid');
        $id = $this->m_alat->getUserid($rfid)->result_array();

        $data = array(
            'id_user' => $id[0]['id'],
            'hari' => date('D'),
            'type' => 'hadir',
            'keterangan' => ''
        );

        $absen = $this->m_alat->submitAbsen_api($data);
        if ($absen) {
            $this->response([
                'status' => 'success',
                'msg' => 'Submit successfully',
                'errors' => null,
                'status_code' => 200
            ], 200);
        }
    }

}
